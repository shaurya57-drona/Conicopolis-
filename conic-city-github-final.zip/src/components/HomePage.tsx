import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ConicType, Building } from '../types';
import { BUILDINGS_DATA } from '../data/buildings';
import { CONIC_INFO, UI_TEXT } from '../data/translations';
import { useLanguage } from '../context/LanguageContext';
import { ConicScene3D } from './ConicScene3D';
import { AcousticRaySimulator } from './AcousticRaySimulator';
import { ConicEquationGrapher } from './ConicEquationGrapher';
import { BuildingCard } from './BuildingCard';
import { BuildingComparison } from './BuildingComparison';
import { MathQuiz } from './MathQuiz';
import { MiniCity3DMap } from './MiniCity3DMap';
import { CityScorecard } from './CityScorecard';
import { AuthBar } from './AuthBar';
import { JudgeFeedbackSection } from './JudgeFeedbackSection';
import {
  Compass,
  Globe,
  Search,
  QrCode,
  Sparkles,
  Scale,
  Cpu,
  CheckCircle2,
  Box,
  ArrowRight,
  Landmark,
  X,
  Camera,
} from 'lucide-react';

interface HomePageProps {
  onOpenBuildingDetail: (building: Building) => void;
  onOpenQRModal: () => void;
  onOpenCompare: () => void;
  onOpenCamOverlay?: () => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  onOpenBuildingDetail,
  onOpenQRModal,
  onOpenCompare,
  onOpenCamOverlay,
}) => {
  const { lang, toggleLanguage } = useLanguage();
  const navigate = useNavigate();

  // Filter & Search states
  const [selectedConicFilter, setSelectedConicFilter] = useState<ConicType | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Active navigation section
  const [activeSection, setActiveSection] = useState<
    'monuments' | '3dlab' | 'acoustics' | 'grapher' | 'compare' | 'quiz' | 'feedback'
  >('monuments');

  // Filter buildings
  const filteredBuildings = BUILDINGS_DATA.filter((b) => {
    const matchesConic = selectedConicFilter === 'all' || b.conicType === selectedConicFilter;
    const query = searchQuery.toLowerCase().trim();
    if (!query) return matchesConic;

    const matchesQuery =
      b.nameEn.toLowerCase().includes(query) ||
      b.nameHi.toLowerCase().includes(query) ||
      b.city.toLowerCase().includes(query) ||
      b.country.toLowerCase().includes(query) ||
      b.architect.toLowerCase().includes(query) ||
      b.conicType.toLowerCase().includes(query);

    return matchesConic && matchesQuery;
  });

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-[#ffffff] selection:bg-[#B6FFED]/30 selection:text-white font-sans">
      {/* Top Fixed Header */}
      <header className="sticky top-0 z-40 bg-[#0a0a0a]/95 backdrop-blur-xl border-b border-[#333333]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
          {/* Brand Logo & Title */}
          <Link to="/" className="flex items-center gap-3 text-white no-underline group">
            <div className="w-10 h-10 rounded-xl bg-[#0e1614] border border-[#B6FFED]/40 p-0.5 shadow-[0_0_15px_rgba(182,255,237,0.18)] flex items-center justify-center group-hover:border-[#B6FFED] transition-colors">
              <Compass className="w-5 h-5 text-[#B6FFED]" />
            </div>
            <div>
              <h1 className="text-base sm:text-lg font-extrabold tracking-tight font-display text-white">
                {UI_TEXT[lang].siteTitle}
              </h1>
              <p className="text-[10px] sm:text-[11px] text-slate-400 font-sans hidden sm:block">
                {UI_TEXT[lang].siteSubtitle}
              </p>
            </div>
          </Link>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-1 text-xs font-medium text-slate-300">
            <button
              onClick={() => setActiveSection('monuments')}
              className={`px-3 py-1.5 rounded-xl transition-all duration-200 ${
                activeSection === 'monuments'
                  ? 'bg-[#B6FFED]/15 text-[#B6FFED] border border-[#B6FFED]/40 font-bold shadow-[0_0_12px_rgba(182,255,237,0.15)]'
                  : 'hover:text-white hover:bg-slate-900 border border-transparent'
              }`}
            >
              {UI_TEXT[lang].navMonuments}
            </button>
            <button
              onClick={() => setActiveSection('3dlab')}
              className={`px-3 py-1.5 rounded-xl transition-all duration-200 ${
                activeSection === '3dlab'
                  ? 'bg-[#B6FFED]/15 text-[#B6FFED] border border-[#B6FFED]/40 font-bold shadow-[0_0_12px_rgba(182,255,237,0.15)]'
                  : 'hover:text-white hover:bg-slate-900 border border-transparent'
              }`}
            >
              {UI_TEXT[lang].navCone3D}
            </button>
            <button
              onClick={() => setActiveSection('acoustics')}
              className={`px-3 py-1.5 rounded-xl transition-all duration-200 ${
                activeSection === 'acoustics'
                  ? 'bg-[#B6FFED]/15 text-[#B6FFED] border border-[#B6FFED]/40 font-bold shadow-[0_0_12px_rgba(182,255,237,0.15)]'
                  : 'hover:text-white hover:bg-slate-900 border border-transparent'
              }`}
            >
              {UI_TEXT[lang].navAcoustics}
            </button>
            <button
              onClick={() => setActiveSection('grapher')}
              className={`px-3 py-1.5 rounded-xl transition-all duration-200 ${
                activeSection === 'grapher'
                  ? 'bg-[#B6FFED]/15 text-[#B6FFED] border border-[#B6FFED]/40 font-bold shadow-[0_0_12px_rgba(182,255,237,0.15)]'
                  : 'hover:text-white hover:bg-slate-900 border border-transparent'
              }`}
            >
              {UI_TEXT[lang].navGrapher}
            </button>
            <Link
              to="/compare"
              className="px-3 py-1.5 rounded-xl transition-all duration-200 hover:text-white hover:bg-slate-900 border border-transparent text-slate-300 no-underline"
            >
              {UI_TEXT[lang].navCompare}
            </Link>
            <button
              onClick={() => setActiveSection('quiz')}
              className={`px-3 py-1.5 rounded-xl transition-all duration-200 ${
                activeSection === 'quiz'
                  ? 'bg-[#B6FFED]/15 text-[#B6FFED] border border-[#B6FFED]/40 font-bold shadow-[0_0_12px_rgba(182,255,237,0.15)]'
                  : 'hover:text-white hover:bg-slate-900 border border-transparent'
              }`}
            >
              {UI_TEXT[lang].navQuiz}
            </button>
            <button
              onClick={() => setActiveSection('feedback')}
              className={`px-3 py-1.5 rounded-xl transition-all duration-200 ${
                activeSection === 'feedback'
                  ? 'bg-[#B6FFED]/15 text-[#B6FFED] border border-[#B6FFED]/40 font-bold shadow-[0_0_12px_rgba(182,255,237,0.15)]'
                  : 'hover:text-white hover:bg-slate-900 border border-transparent'
              }`}
            >
              {UI_TEXT[lang].navFeedback}
            </button>

            {/* Shape Pages Direct Nav (React Router Links) */}
            <div className="h-4 w-px bg-slate-800 mx-1.5" />
            <div className="flex items-center gap-1">
              {(['circle', 'parabola', 'ellipse', 'hyperbola'] as ConicType[]).map((t) => (
                <Link
                  key={t}
                  to={`/${t}`}
                  className="px-2 py-1 rounded-md text-[11px] font-mono text-slate-400 hover:text-[#B6FFED] hover:bg-[#B6FFED]/10 transition-colors uppercase border border-transparent hover:border-[#B6FFED]/30 no-underline"
                  title={`View /${t} Shape Page`}
                >
                  /{t}
                </Link>
              ))}
            </div>
          </nav>

          {/* Action Buttons: AuthBar, AR Camera, QR Code & Bilingual Toggle */}
          <div className="flex items-center gap-2">
            <AuthBar lang={lang} onOpenBuilding={(b) => onOpenBuildingDetail(b)} />

            {/* AR Camera Conic Overlay Trigger */}
            <button
              id="header-camera-ar-button"
              onClick={onOpenCamOverlay}
              className="p-2 sm:px-3 sm:py-1.5 rounded-xl bg-gradient-to-r from-emerald-950/40 via-teal-950/40 to-cyan-950/40 hover:from-emerald-900/60 hover:to-cyan-900/60 text-[#B6FFED] border border-[#B6FFED]/40 hover:border-[#B6FFED] transition-all flex items-center gap-1.5 text-xs font-bold shadow-[0_0_12px_rgba(182,255,237,0.15)] cursor-pointer group"
              title={UI_TEXT[lang].cameraViewTitle}
            >
              <Camera className="w-4 h-4 text-[#B6FFED] group-hover:scale-110 transition-transform" />
              <span className="hidden sm:inline">{UI_TEXT[lang].navCameraAR}</span>
            </button>

            <button
              id="header-qr-button"
              onClick={onOpenQRModal}
              className="p-2 rounded-xl bg-[#141818] hover:bg-[#1a2120] text-slate-300 hover:text-white border border-slate-700/70 hover:border-[#B6FFED]/40 transition-colors flex items-center gap-1.5 text-xs font-semibold"
              title={UI_TEXT[lang].navQR}
            >
              <QrCode className="w-4 h-4 text-[#B6FFED]" />
              <span className="hidden sm:inline">{lang === 'en' ? 'QR Code' : 'क्यूआर'}</span>
            </button>

            {/* Bilingual Toggle EN / HI */}
            <button
              id="language-toggle-button"
              onClick={toggleLanguage}
              className="px-3 py-1.5 rounded-xl bg-[#0f1917] hover:bg-[#152421] text-[#B6FFED] border border-[#B6FFED]/40 transition-all text-xs font-bold flex items-center gap-1.5 shadow-[0_0_10px_rgba(182,255,237,0.1)] cursor-pointer"
              title={lang === 'en' ? 'Switch to Hindi (हिंदी)' : 'Switch to English'}
            >
              <Globe className="w-3.5 h-3.5 text-[#B6FFED]" />
              <span>{lang === 'en' ? 'हिन्दी' : 'EN'}</span>
            </button>
          </div>
        </div>

        {/* Mobile Horizontal Section Tabs */}
        <div className="md:hidden flex items-center overflow-x-auto px-4 py-2 gap-1.5 border-t border-[#333333] bg-[#0a0a0a]/90 text-xs scrollbar-none">
          <button
            onClick={onOpenCamOverlay}
            className="px-3 py-1 rounded-lg shrink-0 transition-colors bg-[#B6FFED]/15 text-[#B6FFED] border border-[#B6FFED]/40 font-bold flex items-center gap-1"
          >
            <Camera className="w-3 h-3" />
            <span>{UI_TEXT[lang].navCameraAR}</span>
          </button>
          <button
            onClick={() => setActiveSection('monuments')}
            className={`px-3 py-1 rounded-lg shrink-0 transition-colors ${
              activeSection === 'monuments' ? 'bg-[#B6FFED]/15 text-[#B6FFED] border border-[#B6FFED]/40 font-bold' : 'text-slate-400'
            }`}
          >
            {UI_TEXT[lang].navMonuments}
          </button>
          <button
            onClick={() => setActiveSection('3dlab')}
            className={`px-3 py-1 rounded-lg shrink-0 transition-colors ${
              activeSection === '3dlab' ? 'bg-[#B6FFED]/15 text-[#B6FFED] border border-[#B6FFED]/40 font-bold' : 'text-slate-400'
            }`}
          >
            {UI_TEXT[lang].navCone3D}
          </button>
          <button
            onClick={() => setActiveSection('acoustics')}
            className={`px-3 py-1 rounded-lg shrink-0 transition-colors ${
              activeSection === 'acoustics' ? 'bg-[#B6FFED]/15 text-[#B6FFED] border border-[#B6FFED]/40 font-bold' : 'text-slate-400'
            }`}
          >
            {UI_TEXT[lang].navAcoustics}
          </button>
          <button
            onClick={() => setActiveSection('grapher')}
            className={`px-3 py-1 rounded-lg shrink-0 transition-colors ${
              activeSection === 'grapher' ? 'bg-[#B6FFED]/15 text-[#B6FFED] border border-[#B6FFED]/40 font-bold' : 'text-slate-400'
            }`}
          >
            {UI_TEXT[lang].navGrapher}
          </button>
          <Link
            to="/compare"
            className="px-3 py-1 rounded-lg shrink-0 transition-colors text-slate-400 hover:text-white"
          >
            {UI_TEXT[lang].navCompare}
          </Link>
          <button
            onClick={() => setActiveSection('quiz')}
            className={`px-3 py-1 rounded-lg shrink-0 transition-colors ${
              activeSection === 'quiz' ? 'bg-[#B6FFED]/15 text-[#B6FFED] border border-[#B6FFED]/40 font-bold' : 'text-slate-400'
            }`}
          >
            {UI_TEXT[lang].navQuiz}
          </button>
          <button
            onClick={() => setActiveSection('feedback')}
            className={`px-3 py-1 rounded-lg shrink-0 transition-colors ${
              activeSection === 'feedback' ? 'bg-[#B6FFED]/15 text-[#B6FFED] border border-[#B6FFED]/40 font-bold' : 'text-slate-400'
            }`}
          >
            {UI_TEXT[lang].navFeedback}
          </button>
        </div>
      </header>

      {/* Hero Mathematical Banner */}
      <section className="relative overflow-hidden pt-8 pb-10 border-b border-[#333333] bg-[#0a0a0a] blueprint-grid">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-3xl mx-auto mb-8">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#B6FFED]/10 border border-[#B6FFED]/30 text-[#B6FFED] text-xs font-mono font-medium mb-3.5 shadow-[0_0_15px_rgba(182,255,237,0.12)]">
              <Sparkles className="w-3.5 h-3.5 text-[#B6FFED]" />
              <span>{UI_TEXT[lang].tagline}</span>
            </div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-black tracking-tight text-white font-display mb-3">
              {lang === 'en' ? 'Conic City: Geometry in Architecture' : 'कॉनिक सिटी: वास्तुकला में ज्यामिति'}
            </h2>
            <p className="text-xs sm:text-sm md:text-base text-slate-300 leading-relaxed font-sans max-w-2xl mx-auto">
              {lang === 'en'
                ? 'Discover how circles, parabolas, ellipses, and hyperbolas govern structural equilibrium, acoustic whispering, and material efficiency across 16 world-renowned monuments.'
                : 'जानें कि कैसे वृत्त, परवलय, दीर्घवृत्त और अतिपरवलय 16 विश्व प्रसिद्ध स्मारकों में संरचनात्मक संतुलन, ध्वनिकी और सामग्री दक्षता को नियंत्रित करते हैं।'}
            </p>

            {/* Quick Hero Actions */}
            <div className="flex flex-wrap items-center justify-center gap-3 mt-5">
              <a
                href="#conic-city-3d-map"
                className="px-5 py-2.5 rounded-xl text-xs font-bold bg-[#B6FFED] hover:bg-[#9effe4] text-[#0a0a0a] transition-all duration-200 shadow-[0_0_20px_rgba(182,255,237,0.3)] hover:shadow-[0_0_28px_rgba(182,255,237,0.45)] flex items-center gap-1.5 no-underline"
              >
                <span>{lang === 'en' ? 'Explore 3D City Map' : '3D नगर मैप देखें'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </a>

              <button
                id="hero-camera-ar-button"
                onClick={onOpenCamOverlay}
                className="px-5 py-2.5 rounded-xl text-xs font-bold bg-[#0e1615] hover:bg-[#142321] text-[#B6FFED] transition-all duration-200 border border-[#B6FFED]/50 hover:border-[#B6FFED] shadow-[0_0_18px_rgba(182,255,237,0.18)] flex items-center gap-2 cursor-pointer group"
              >
                <Camera className="w-4 h-4 text-[#B6FFED] group-hover:scale-110 transition-transform" />
                <span>{UI_TEXT[lang].navCameraAR}</span>
              </button>

              <Link
                to="/compare"
                className="px-5 py-2.5 rounded-xl text-xs font-bold bg-[#141617] hover:bg-[#1a1d1d] text-slate-200 hover:text-white transition-all duration-200 border border-slate-700 hover:border-[#B6FFED]/50 flex items-center gap-1.5 no-underline"
              >
                <Scale className="w-3.5 h-3.5 text-[#B6FFED]" />
                <span>{lang === 'en' ? 'Compare Structures' : 'संरचना तुलना'}</span>
              </Link>
            </div>
          </div>

          {/* 4 Clear Shape Entry Cards (Circle, Parabola, Ellipse, Hyperbola) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {(['circle', 'parabola', 'ellipse', 'hyperbola'] as ConicType[]).map((type) => {
              const info = CONIC_INFO[type];
              const isSelected = selectedConicFilter === type;

              const shapeConcept = {
                circle: {
                  en: 'Uniform 360° hoop stress & maximum floor area envelope.',
                  hi: 'समान 360° हूप तनाव व अधिकतम क्षेत्रफल आवरण।',
                  border: 'hover:border-sky-500/80',
                  color: '#38bdf8',
                },
                parabola: {
                  en: 'Pure axial compression catenaries & zero bending moments.',
                  hi: 'शुद्ध अक्षीय संपीड़न व शून्य बेंडिंग मोमेंट मेहराब।',
                  border: 'hover:border-orange-500/80',
                  color: '#fb923c',
                },
                ellipse: {
                  en: 'Bifocal acoustic reflection & aerodynamic arena profiles.',
                  hi: 'दोहरी नाभि ध्वनि परावर्तन व पवन विक्षेपण एरेना।',
                  border: 'hover:border-emerald-500/80',
                  color: '#34d399',
                },
                hyperbola: {
                  en: 'Doubly-ruled straight-beam lattice & natural draft cooling.',
                  hi: 'सीधी बीम से निर्मित मीनारें व प्राकृतिक वायु संवहन।',
                  border: 'hover:border-purple-500/80',
                  color: '#c084fc',
                },
              }[type];

              return (
                <div
                  key={type}
                  id={`hero-card-${type}`}
                  className={`group relative rounded-2xl p-5 transition-all duration-300 border flex flex-col justify-between bg-slate-900/80 backdrop-blur-sm shadow-lg ${
                    isSelected
                      ? 'border-sky-500 bg-slate-800/90 shadow-sky-500/10'
                      : `border-slate-800 ${shapeConcept.border}`
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <div
                        className="w-8 h-8 rounded-xl flex items-center justify-center font-bold text-base"
                        style={{
                          backgroundColor: `${shapeConcept.color}20`,
                          color: shapeConcept.color,
                        }}
                      >
                        {info.symbol}
                      </div>
                      <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-slate-950 text-amber-300 font-bold border border-slate-800">
                        {info.eccentricityDef}
                      </span>
                    </div>

                    <h3 className="text-lg font-bold text-white font-display uppercase tracking-wide mt-1">
                      {lang === 'en' ? info.nameEn : info.nameHi}
                    </h3>
                    <div className="text-[11px] font-mono text-slate-400 mb-2">
                      {info.generalEquation}
                    </div>

                    <p className="text-xs text-slate-300 leading-relaxed mb-4">
                      {lang === 'en' ? shapeConcept.en : shapeConcept.hi}
                    </p>
                  </div>

                  <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between">
                    <button
                      onClick={() => {
                        setSelectedConicFilter(type);
                        setActiveSection('monuments');
                      }}
                      className="text-xs text-slate-400 hover:text-white cursor-pointer transition-colors"
                    >
                      {info.count} {lang === 'en' ? 'Structures' : 'इमारतें'}
                    </button>

                    <Link
                      to={`/${type}`}
                      className="px-3 py-1 rounded-lg text-xs font-bold text-white transition-all flex items-center gap-1 cursor-pointer shadow-md hover:scale-105 no-underline"
                      style={{ backgroundColor: shapeConcept.color }}
                      title={`Open dedicated /${type} 3D page`}
                    >
                      <span>/{type}</span>
                      <ArrowRight className="w-3 h-3" />
                    </Link>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Main Interactive Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-12">
        {/* SECTION: MINI 3D MAP PREVIEW (Three.js real interactive city preview) */}
        <section id="conic-city-3d-map" className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
            <div>
              <h3 className="text-xl sm:text-2xl font-bold text-white font-display flex items-center gap-2">
                <Box className="w-5 h-5 text-sky-400" />
                <span>{lang === 'en' ? 'Conic City 3D Mini Map' : 'कॉनिक सिटी 3D लघु मानचित्र'}</span>
              </h3>
              <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
                {lang === 'en'
                  ? 'Interactive Three.js isometric cluster demonstrating the 4 conic zones. Drag to rotate; click any district to enter.'
                  : '4 कॉनिक क्षेत्रों का Three.js 3D मॉडल। घुमाने के लिए ड्रैग करें, विस्तृत पृष्ठ देखने के लिए क्लिक करें।'}
              </p>
            </div>
            <span className="text-xs font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 px-2.5 py-1 rounded-lg self-start sm:self-auto">
              Real Three.js WebGL
            </span>
          </div>

          <MiniCity3DMap lang={lang} onSelectShape={(shape) => navigate(`/${shape}`)} />
        </section>

        {/* SECTION: REAL ARCHITECTURE CALLOUT */}
        <section className="bg-gradient-to-r from-slate-900 via-slate-900/90 to-slate-950 border border-slate-800 rounded-2xl p-6 sm:p-7 shadow-xl">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4 pb-3 border-b border-slate-800/80">
            <div className="flex items-center gap-3">
              <span className="p-2 rounded-xl bg-amber-500/15 text-amber-400 border border-amber-500/30">
                <Landmark className="w-5 h-5" />
              </span>
              <div>
                <h3 className="text-lg sm:text-xl font-bold text-white font-display">
                  {lang === 'en' ? '16 Researched Real-World Buildings' : '16 वास्तविक दुनिया की प्रमाणित इमारतें'}
                </h3>
                <span className="text-xs text-slate-400">
                  {lang === 'en'
                    ? 'Engineered by Roman masters, Eero Saarinen, Antoni Gaudí, Sir Christopher Wren, and Vladimir Shukhov'
                    : 'रोमन कारीगरों, ईरो सारिनेन, एंटोनी गौडी और व्लादिमीर शुखोव की विश्वप्रसिद्ध कृतियाँ'}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              <span>100% Local Equations</span>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs text-slate-300">
            <div className="bg-slate-950/60 p-3 rounded-xl border border-sky-900/40">
              <div className="font-bold text-sky-400 font-mono mb-1">Circles (e = 0)</div>
              <div className="text-slate-400 text-[11px] leading-relaxed">
                The Pantheon (Rome), Apple Park (Cupertino), Lotus Temple (New Delhi), Cappadocia Church (Turkey)
              </div>
            </div>

            <div className="bg-slate-950/60 p-3 rounded-xl border border-orange-900/40">
              <div className="font-bold text-orange-400 font-mono mb-1">Parabolas (e = 1)</div>
              <div className="text-slate-400 text-[11px] leading-relaxed">
                Gateway Arch (St. Louis), Golden Gate Bridge (SF), Valle de los Caídos (Spain), St. Louis Planetarium
              </div>
            </div>

            <div className="bg-slate-950/60 p-3 rounded-xl border border-emerald-900/40">
              <div className="font-bold text-emerald-400 font-mono mb-1">Ellipses (0 &lt; e &lt; 1)</div>
              <div className="text-slate-400 text-[11px] leading-relaxed">
                Colosseum (Rome), St. Paul’s Cathedral (London), Statuary Hall (DC), Sydney Olympic Stadium
              </div>
            </div>

            <div className="bg-slate-950/60 p-3 rounded-xl border border-purple-900/40">
              <div className="font-bold text-purple-400 font-mono mb-1">Hyperbolas (e &gt; 1)</div>
              <div className="text-slate-400 text-[11px] leading-relaxed">
                Canton Tower (Guangzhou), Sagrada Família (Barcelona), Kobe Port Tower (Japan), Cooling Towers
              </div>
            </div>
          </div>
        </section>

        {/* SECTION: CITY SCORECARD PREVIEW */}
        <section>
          <CityScorecard mode="city" lang={lang} />
        </section>

        {/* VIEW 1: 16 Monuments Masterworks Grid */}
        {activeSection === 'monuments' && (
          <section id="monuments-section" className="space-y-6">
            {/* Filter and Search Bar */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#0e1112]/90 p-4 rounded-2xl border border-[#333333]">
              {/* Filter Tabs */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 md:pb-0">
                <button
                  id="filter-all"
                  onClick={() => setSelectedConicFilter('all')}
                  className={`text-xs px-3.5 py-1.5 rounded-xl font-semibold transition-all shrink-0 border ${
                    selectedConicFilter === 'all'
                      ? 'bg-[#B6FFED]/15 text-[#B6FFED] border-[#B6FFED]/40 font-bold shadow-[0_0_12px_rgba(182,255,237,0.15)]'
                      : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white hover:border-slate-700'
                  }`}
                >
                  {UI_TEXT[lang].filterAll}
                </button>
                {(['circle', 'parabola', 'ellipse', 'hyperbola'] as ConicType[]).map((type) => {
                  const info = CONIC_INFO[type];
                  return (
                    <button
                      key={type}
                      id={`filter-${type}`}
                      onClick={() => setSelectedConicFilter(type)}
                      className={`text-xs px-3.5 py-1.5 rounded-xl font-semibold transition-all shrink-0 border ${
                        selectedConicFilter === type
                          ? `${info.badgeBg}`
                          : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white hover:border-slate-700'
                      }`}
                    >
                      {info.symbol} {lang === 'en' ? info.nameEn : info.nameHi}
                    </button>
                  );
                })}
              </div>

              {/* Search Box */}
              <div className="relative w-full md:w-80">
                <Search className="w-4 h-4 text-[#B6FFED]/70 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  id="search-buildings-input"
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={UI_TEXT[lang].searchPlaceholder}
                  className="w-full bg-[#080a0a] border border-slate-700/80 rounded-xl pl-9 pr-8 py-2 text-xs sm:text-sm text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-[#B6FFED] focus:ring-1 focus:ring-[#B6FFED]/30 transition-all"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white p-0.5 rounded-full hover:bg-slate-800 transition-colors"
                    title={lang === 'en' ? 'Clear search' : 'खोज साफ करें'}
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>

            {/* Active search results counter indicator */}
            {searchQuery.trim() && (
              <div className="flex items-center justify-between px-1 text-xs text-slate-300">
                <div className="flex items-center gap-2">
                  <span className="inline-block w-2 h-2 rounded-full bg-[#B6FFED] shadow-[0_0_8px_#B6FFED] animate-pulse" />
                  <span>
                    {lang === 'en' ? 'Highlighting matches for ' : 'परिणाम खोज '}
                    <strong className="text-[#0a0a0a] font-bold bg-[#B6FFED] px-2 py-0.5 rounded shadow-[0_0_10px_rgba(182,255,237,0.3)]">
                      "{searchQuery.trim()}"
                    </strong>
                    <span className="text-slate-400 ml-1.5">
                      ({filteredBuildings.length} {lang === 'en' ? (filteredBuildings.length === 1 ? 'structure found' : 'structures found') : 'इमारतें मिलीं'})
                    </span>
                  </span>
                </div>
                <button
                  onClick={() => setSearchQuery('')}
                  className="text-xs text-[#B6FFED] hover:underline font-semibold"
                >
                  {lang === 'en' ? 'Clear search' : 'खोज हटाएं'}
                </button>
              </div>
            )}

            {/* Buildings Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
              {filteredBuildings.map((building) => (
                <BuildingCard
                  key={building.id}
                  building={building}
                  lang={lang}
                  searchQuery={searchQuery}
                  onOpenDetails={(b) => onOpenBuildingDetail(b)}
                  onOpenCompare={onOpenCompare}
                />
              ))}
            </div>

            {filteredBuildings.length === 0 && (
              <div className="text-center py-12 bg-slate-900/40 rounded-2xl border border-slate-800">
                <p className="text-slate-400 text-sm">
                  {lang === 'en' ? 'No architectural structures matched your search query.' : 'आपकी खोज से मेल खाती कोई इमारत नहीं मिली।'}
                </p>
              </div>
            )}
          </section>
        )}

        {/* VIEW 2: 3D Double Cone Slicer */}
        {activeSection === '3dlab' && (
          <section id="slicer-section" className="space-y-6">
            <ConicScene3D
              lang={lang}
              onSelectConic={(conic) => {
                setSelectedConicFilter(conic);
                setActiveSection('monuments');
              }}
            />
          </section>
        )}

        {/* VIEW 3: Acoustic & Optics Ray Simulator */}
        {activeSection === 'acoustics' && (
          <section id="acoustics-section" className="space-y-6">
            <AcousticRaySimulator lang={lang} />
          </section>
        )}

        {/* VIEW 4: Equation Engine & Discriminant */}
        {activeSection === 'grapher' && (
          <section id="grapher-section" className="space-y-6">
            <ConicEquationGrapher lang={lang} />
          </section>
        )}

        {/* VIEW 5: Architecture Comparison Matrix */}
        {activeSection === 'compare' && (
          <section id="compare-section" className="space-y-6">
            <BuildingComparison lang={lang} />
          </section>
        )}

        {/* VIEW 6: Judge Challenge Math Quiz */}
        {activeSection === 'quiz' && (
          <section id="quiz-section" className="space-y-8">
            <MathQuiz lang={lang} />
            <div className="pt-2">
              <JudgeFeedbackSection lang={lang} />
            </div>
          </section>
        )}

        {/* VIEW 7: Judge Evaluation & Feedback (Firestore) */}
        {activeSection === 'feedback' && (
          <section id="feedback-section" className="space-y-6">
            <JudgeFeedbackSection lang={lang} />
          </section>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-[#333333] bg-[#0a0a0a] py-10 mt-16 text-[#b0b0b0] text-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <div className="flex items-center gap-2 font-display text-white font-bold text-sm mb-1">
                <Compass className="w-4 h-4 text-sky-400" />
                <span>CONIC CITY — GEOMETRY IN ARCHITECTURE</span>
              </div>
              <p className="text-slate-500 max-w-xl text-[11px] leading-relaxed">
                {lang === 'en'
                  ? 'A production-grade educational platform demonstrating how mathematical conic sections shape iconic global architecture with Three.js 3D simulations. Built for math-heavy evaluation, science exhibitions, and architectural acoustics studies.'
                  : 'वैश्विक वास्तुकला में गणितीय शंकु परिच्छेदों के महत्व को Three.js 3D सिमुलेशन के साथ प्रदर्शित करने वाला शैक्षणिक मंच। गणितीय मूल्यांकन एवं स्थापत्य ध्वनिकी अध्ययन हेतु निर्मित।'}
              </p>
            </div>

            {/* Language toggle duplicate in footer */}
            <div className="flex items-center gap-3 shrink-0">
              <span className="text-[11px] text-slate-500 font-mono">{lang === 'en' ? 'Language:' : 'भाषा:'}</span>
              <button
                onClick={toggleLanguage}
                className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white border border-slate-700 transition-colors text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
              >
                <Globe className="w-3.5 h-3.5 text-sky-400" />
                <span>{lang === 'en' ? 'हिन्दी (Hindi)' : 'English'}</span>
              </button>
            </div>
          </div>

          {/* Performance & Spec Badges */}
          <div className="pt-4 border-t border-slate-900 flex flex-wrap items-center justify-between gap-4 font-mono text-[11px]">
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-emerald-400 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Lighthouse 95+</span>
              </span>
              <span className="px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-sky-400 flex items-center gap-1">
                <Cpu className="w-3.5 h-3.5" />
                <span>WebGL 60 FPS</span>
              </span>
              <span className="px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-purple-400">
                Zero-Backend Local
              </span>
              <span className="px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-amber-400">
                Android 14+ Ready
              </span>
            </div>
            <div className="text-slate-600 text-[10px]">
              Circle (e=0) • Parabola (e=1) • Ellipse (0&lt;e&lt;1) • Hyperbola (e&gt;1)
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};
