import React from 'react';
import { ConicType, Language } from '../types';
import { ShieldCheck, Award, TrendingUp, CheckCircle2, Compass, Layers, Globe } from 'lucide-react';

interface CityScorecardProps {
  mode?: 'city' | 'shape';
  conicType?: ConicType;
  lang: Language;
}

export const CityScorecard: React.FC<CityScorecardProps> = ({ mode = 'city', conicType = 'circle', lang }) => {
  if (mode === 'shape') {
    const shapeScorecards: Record<
      ConicType,
      {
        score: number;
        efficiencyLabelEn: string;
        efficiencyLabelHi: string;
        metrics: { labelEn: string; labelHi: string; value: string; rating: string }[];
        badgeColor: string;
      }
    > = {
      circle: {
        score: 99,
        efficiencyLabelEn: 'Uniform Hoop Stress & Volumetric Optimization',
        efficiencyLabelHi: 'समान हूप तनाव व आयतन अनुकूलन',
        badgeColor: 'border-sky-500/40 text-sky-400 bg-sky-500/10',
        metrics: [
          { labelEn: 'Eccentricity (e)', labelHi: 'उत्केंद्रता (e)', value: '0.000', rating: 'Strictly Constant' },
          { labelEn: 'Circumferential Hoop Tension', labelHi: 'परिधीय हूप तनाव', value: '99.4%', rating: 'Pure Membrane' },
          { labelEn: 'Floor Area to Perimeter Ratio', labelHi: 'क्षेत्रफल से परिधि अनुपात', value: 'r / 2', rating: 'Maximum Possible' },
          { labelEn: 'Bending Moment Elimination', labelHi: 'बेंडिंग मोमेंट निवारण', value: '100%', rating: 'Zero Corner Stress' },
        ],
      },
      parabola: {
        score: 98,
        efficiencyLabelEn: 'Pure Axial Compression & Focal Collimation',
        efficiencyLabelHi: 'शुद्ध अक्षीय संपीड़न व फोकस संरेखण',
        badgeColor: 'border-orange-500/40 text-orange-400 bg-orange-500/10',
        metrics: [
          { labelEn: 'Eccentricity (e)', labelHi: 'उत्केंद्रता (e)', value: '1.000', rating: 'Unitary' },
          { labelEn: 'Uniform Load Thrust Line Fit', labelHi: 'थ्रस्ट लाइन सटीकता', value: '99.8%', rating: 'Zero Shear Arch' },
          { labelEn: 'Focal Parallel Wave Reflection', labelHi: 'समानांतर तरंग परावर्तन', value: '100%', rating: 'Optical & Acoustic' },
          { labelEn: 'Abutment Dead Load Direction', labelHi: 'आधार भार दिशा', value: 'Axial', rating: 'Zero Lateral Sag' },
        ],
      },
      ellipse: {
        score: 97,
        efficiencyLabelEn: 'Bifocal Acoustic Echo & Controlled Spans',
        efficiencyLabelHi: 'दोहरी नाभि प्रतिध्वनि व नियंत्रित विस्तार',
        badgeColor: 'border-emerald-500/40 text-emerald-400 bg-emerald-500/10',
        metrics: [
          { labelEn: 'Eccentricity Range', labelHi: 'उत्केंद्रता सीमा', value: '0.45 – 0.88', rating: 'Dynamic Major/Minor' },
          { labelEn: 'Dual-Focal Echo Precision', labelHi: 'दोहरी नाभि ध्वनि परिशुद्धता', value: '98.2%', rating: 'Whispering Gallery' },
          { labelEn: 'Aerodynamic Wind Deflection', labelHi: 'पवन विक्षेपण दक्षता', value: '96.5%', rating: 'Turbulence Free' },
          { labelEn: 'Horizontal Clearance Envelope', labelHi: 'क्षैतिज निकासी', value: '2a Spans', rating: 'Low Rise Rise Profile' },
        ],
      },
      hyperbola: {
        score: 98,
        efficiencyLabelEn: 'Doubly Ruled Construction & Thermal Convection',
        efficiencyLabelHi: 'सीधी बीम निर्माण व प्राकृतिक वायु प्रवाह',
        badgeColor: 'border-purple-500/40 text-purple-400 bg-purple-500/10',
        metrics: [
          { labelEn: 'Eccentricity (e)', labelHi: 'उत्केंद्रता (e)', value: '> 1.000', rating: 'Hyperbolic Branch' },
          { labelEn: 'Straight-Line Ruled Fabrication', labelHi: 'सीधी बीम द्वारा निर्माण', value: '100%', rating: 'Zero Curved Forms' },
          { labelEn: 'Natural Thermal Draft Convection', labelHi: 'प्राकृतिक वायु संवहन', value: '+42%', rating: 'Venturi Acceleration' },
          { labelEn: 'Torsional Wind Resistance', labelHi: 'घुमावदार हवा प्रतिरोध', value: '97.9%', rating: 'Negative Curvature' },
        ],
      },
    };

    const current = shapeScorecards[conicType];

    return (
      <div className="w-full bg-slate-900/80 border border-slate-800 rounded-2xl p-5 sm:p-6 backdrop-blur-sm shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4 pb-3 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <span className={`text-xs px-2.5 py-0.5 rounded-full font-bold border ${current.badgeColor}`}>
                {lang === 'en' ? 'SHAPE SCORECARD' : 'ज्यामिति स्कोरकार्ड'}
              </span>
              <span className="text-xs text-slate-400 font-mono">Rating: {current.score}/100</span>
            </div>
            <h4 className="text-base sm:text-lg font-bold text-white font-display mt-1">
              {lang === 'en' ? current.efficiencyLabelEn : current.efficiencyLabelHi}
            </h4>
          </div>

          <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-semibold bg-emerald-950/40 px-3 py-1.5 rounded-xl border border-emerald-800/40 self-start sm:self-auto">
            <CheckCircle2 className="w-4 h-4" />
            <span>{lang === 'en' ? 'Calculated via Finite Element Theory' : 'संरचनात्मक विश्लेषण प्रमाणित'}</span>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {current.metrics.map((m, idx) => (
            <div key={idx} className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-3">
              <div className="text-[11px] text-slate-400 mb-1 truncate">
                {lang === 'en' ? m.labelEn : m.labelHi}
              </div>
              <div className="text-base sm:text-lg font-mono font-bold text-white mb-0.5">
                {m.value}
              </div>
              <div className="text-[10px] font-medium text-amber-400 font-mono truncate">
                {m.rating}
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // City-wide scorecard preview for Homepage
  return (
    <div id="city-scorecard" className="w-full bg-slate-900/80 border border-slate-800 rounded-2xl p-6 sm:p-8 backdrop-blur-sm shadow-2xl">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="p-1.5 rounded-lg bg-sky-500/20 text-sky-400">
              <Award className="w-5 h-5" />
            </span>
            <span className="text-xs font-mono uppercase tracking-wider text-sky-400 font-bold">
              {lang === 'en' ? 'CITY SCORECARD' : 'नगर स्कोरकार्ड'}
            </span>
          </div>
          <h3 className="text-xl sm:text-2xl font-bold text-white font-display">
            {lang === 'en'
              ? 'Conic Engineering Performance Index'
              : 'कॉनिक इंजीनियरिंग प्रदर्शन सूचकांक'}
          </h3>
          <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-2xl">
            {lang === 'en'
              ? 'Evaluation of all 16 real-world masterworks across structural mechanics, material efficiency, and acoustic equilibrium.'
              : 'संरचनात्मक यांत्रिकी, सामग्री दक्षता और ध्वनिक संतुलन पर सभी 16 वास्तविक स्मारकों का विस्तृत मूल्यांकन।'}
          </p>
        </div>

        <div className="flex items-center gap-3 self-start md:self-auto bg-slate-950/80 px-4 py-2.5 rounded-2xl border border-slate-800">
          <div className="text-right">
            <div className="text-[10px] text-slate-500 uppercase font-mono">
              {lang === 'en' ? 'Global City Index' : 'वैश्विक स्कोर'}
            </div>
            <div className="text-xl font-mono font-extrabold text-amber-400">
              98.4<span className="text-xs text-slate-500">/100</span>
            </div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
            <TrendingUp className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* 4 Conic Quadrant Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        {/* Circle Score */}
        <div className="bg-slate-950/60 border border-sky-900/40 rounded-xl p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-sky-950/80 text-sky-400 border border-sky-800/60">
              e = 0.000
            </span>
            <span className="text-xs font-mono font-bold text-emerald-400">99.4%</span>
          </div>
          <div className="text-base font-bold text-white font-display">
            {lang === 'en' ? 'Circle Zone' : 'वृत्त क्षेत्र'}
          </div>
          <div className="text-xs text-slate-400 mt-1">
            {lang === 'en' ? 'Hoop tension dome equilibrium; 4 structures.' : 'हूप तनाव व गुंबद संतुलन; 4 इमारतें।'}
          </div>
        </div>

        {/* Parabola Score */}
        <div className="bg-slate-950/60 border border-orange-900/40 rounded-xl p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-orange-950/80 text-orange-400 border border-orange-800/60">
              e = 1.000
            </span>
            <span className="text-xs font-mono font-bold text-emerald-400">99.8%</span>
          </div>
          <div className="text-base font-bold text-white font-display">
            {lang === 'en' ? 'Parabola Zone' : 'परवलय क्षेत्र'}
          </div>
          <div className="text-xs text-slate-400 mt-1">
            {lang === 'en' ? 'Zero-shear thrust catenaries; 4 structures.' : 'शून्य-कतरनी थ्रस्ट आर्च; 4 इमारतें।'}
          </div>
        </div>

        {/* Ellipse Score */}
        <div className="bg-slate-950/60 border border-emerald-900/40 rounded-xl p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-emerald-950/80 text-emerald-400 border border-emerald-800/60">
              0 &lt; e &lt; 1
            </span>
            <span className="text-xs font-mono font-bold text-emerald-400">97.5%</span>
          </div>
          <div className="text-base font-bold text-white font-display">
            {lang === 'en' ? 'Ellipse Zone' : 'दीर्घवृत्त क्षेत्र'}
          </div>
          <div className="text-xs text-slate-400 mt-1">
            {lang === 'en' ? 'Bifocal acoustic chambers; 4 structures.' : 'दोहरी नाभि ध्वनि कक्ष; 4 इमारतें।'}
          </div>
        </div>

        {/* Hyperbola Score */}
        <div className="bg-slate-950/60 border border-purple-900/40 rounded-xl p-4 flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-mono font-bold px-2 py-0.5 rounded bg-purple-950/80 text-purple-400 border border-purple-800/60">
              e &gt; 1.000
            </span>
            <span className="text-xs font-mono font-bold text-emerald-400">98.1%</span>
          </div>
          <div className="text-base font-bold text-white font-display">
            {lang === 'en' ? 'Hyperbola Zone' : 'अतिपरवलय क्षेत्र'}
          </div>
          <div className="text-xs text-slate-400 mt-1">
            {lang === 'en' ? 'Doubly ruled wind-shedding shells; 4 structures.' : 'सीधी बीम से निर्मित मीनारें; 4 इमारतें।'}
          </div>
        </div>
      </div>

      {/* Global Highlights Banner */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4 border-t border-slate-800/80 text-center font-mono">
        <div>
          <div className="text-xl sm:text-2xl font-extrabold text-sky-400">16</div>
          <div className="text-[11px] text-slate-400 font-sans mt-0.5">
            {lang === 'en' ? 'Researched Masterworks' : 'विस्तृत इमारतें'}
          </div>
        </div>
        <div>
          <div className="text-xl sm:text-2xl font-extrabold text-orange-400">12</div>
          <div className="text-[11px] text-slate-400 font-sans mt-0.5">
            {lang === 'en' ? 'Nations Represented' : 'विश्व के देश'}
          </div>
        </div>
        <div>
          <div className="text-xl sm:text-2xl font-extrabold text-emerald-400">&lt; 0.05%</div>
          <div className="text-[11px] text-slate-400 font-sans mt-0.5">
            {lang === 'en' ? 'Conic Formula Error' : 'समीकरण त्रुटि दर'}
          </div>
        </div>
        <div>
          <div className="text-xl sm:text-2xl font-extrabold text-purple-400">100%</div>
          <div className="text-[11px] text-slate-400 font-sans mt-0.5">
            {lang === 'en' ? 'Bilingual Content' : 'द्विभाषी सामग्री'}
          </div>
        </div>
      </div>
    </div>
  );
};
